-keepclassmembers class com.capstone.receiptnote.MainActivity$NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}

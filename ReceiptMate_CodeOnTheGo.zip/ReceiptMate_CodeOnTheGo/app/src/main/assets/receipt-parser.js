/* Korean retail receipt parser: deterministic, transparent, and user-editable.
   Not a trained AI classifier. Exports functions to Android WebView and Node tests. */
(function (root) {
  'use strict';
  const IGNORE_ITEM = /(합\s*계|총\s*액|결제|승인|부가세|과세|면세|공급가|공급액|할인|카드|현금|잔돈|거스름|사업자|등록번호|전화|주소|영수증|거래일|영업일|일시|번호|VAT|TAX|TEL|TOTAL|CASH|SUBTOTAL|포인트|적립|금액|합\s*산)/i;
  const CATEGORY_RULES = [
    ['식비', /(CU|GS25|GS\s*25|세븐일레븐|이마트24|편의점|식당|김밥|치킨|피자|버거|카페|커피|스타벅스|투썸|메가커피|빽다방|공차|음료|식품|제과|베이커리|맘스터치|맥도날드|롯데리아|배달|샐러드|분식|라면|우유|음식)/i],
    ['교통비', /(택시|버스|지하철|교통|고속도로|하이패스|기차|철도|KTX|SRT|주유|충전소|주차|톨게이트)/i],
    ['생활비', /(이마트|홈플러스|롯데마트|다이소|올리브영|생필품|세제|비누|샴푸|휴지|마트|약국|의약품|문구)/i],
    ['쇼핑', /(무신사|쿠팡|쇼핑|의류|백화점|스파오|유니클로|신발|가방|온라인몰)/i],
    ['의료비', /(병원|의원|치과|진료|검사|한의원|의료)/i],
    ['문화·여가', /(영화|CGV|메가박스|롯데시네마|전시|노래방|게임|도서|서점|공연)/i]
  ];
  function digits(v) { return String(v || '').replace(/[^\d]/g, ''); }
  function amount(v) {
    const n = Number(digits(v));
    return Number.isSafeInteger(n) && n >= 0 ? n : 0;
  }
  function normalize(s) {
    return String(s || '').normalize('NFKC').replace(/\r/g, '\n')
      .replace(/[￦₩]/g, '₩').replace(/[，]/g, ',').replace(/\u00a0/g, ' ');
  }
  function parseDateString(s) {
    const v = String(s || '');
    let m = v.match(/\b(20\d{2}|19\d{2})[.\-/년\s]+(\d{1,2})[.\-/월\s]+(\d{1,2})\b/);
    if (!m) m = v.match(/\b(\d{2})[.\-/](\d{1,2})[.\-/](\d{1,2})\b/);
    if (!m) m = v.match(/\b(20\d{2}|19\d{2})(\d{2})(\d{2})\b/);
    if (!m) return '';
    let year = Number(m[1]);
    if (year < 100) year += 2000;
    const month = Number(m[2]), day = Number(m[3]);
    const date = new Date(year, month - 1, day);
    if (date.getFullYear() !== year || date.getMonth() + 1 !== month || date.getDate() !== day) return '';
    return String(year).padStart(4, '0') + '-' + String(month).padStart(2, '0') + '-' + String(day).padStart(2, '0');
  }
  function inferCategory(store, items) {
    const combined = `${store || ''} ${(items || []).map(x => x.name || '').join(' ')}`;
    for (const [cat, re] of CATEGORY_RULES) if (re.test(combined)) return cat;
    return '기타';
  }
  function extractMoney(line) {
    // Avoid confusing dates or times with money. Value should be 3+ digits or comma grouped.
    const moneyTokens = String(line).match(/(?:₩\s*)?-?\d{1,3}(?:,\d{3})+(?:\s*원)?|(?:₩\s*)?-?\d{3,10}\s*원?\b/g) || [];
    return moneyTokens.map(x => ({ value: amount(x), token: x })).filter(x => x.value > 0 && x.value < 1000000000);
  }
  function merchantOf(lines) {
    const labeled = lines.find(x => /(?:상\s*호\s*명?|가\s*맹\s*점|매\s*장\s*명)\s*[:：]/.test(x));
    if (labeled) {
      const s = labeled.replace(/^.*?(상\s*호\s*명?|가\s*맹\s*점|매\s*장\s*명)\s*[:：]\s*/, '').trim();
      if (s && /[가-힣A-Za-z]/.test(s) && s.length < 80) return s;
    }
    const ignored = /(영수증|거래|승인|매출|신용|카드|고객|구매|품명|상품|합계|금액|사업자|대표자|주소|전화|TEL|감사|환영|포인트|전표|수량|단가|품목|RECEIPT)/i;
    for (const line of lines.slice(0, 10)) {
      const clean = line.replace(/[\[\]★☆◆◈*#]/g, '').trim();
      if (clean.length >= 2 && clean.length < 55 && /[가-힣A-Za-z]/.test(clean)
          && !ignored.test(clean) && !/^\d/.test(clean) && !/\d{3,}/.test(clean)) return clean;
    }
    return '';
  }
  function totalOf(lines) {
    let strongest = { value: 0, weight: -1 };
    const priority = [
      [/^(?:\s*)(?:총\s*결제\s*금액|실\s*결제\s*금액|최종\s*결제|받을\s*금액|결제\s*금액|총\s*금액|총\s*합계|카드\s*승인\s*금액)/i, 18],
      [/(?:^|\s)(?:합\s*계|총\s*액|TOTAL|결제\s*금액)(?:\s|[:：]|$)/i, 15],
      [/(카드\s*결제|현금\s*결제|승인\s*금액|받은\s*금액)/i, 12]
    ];
    lines.forEach((line, i) => {
      const matched = priority.find(([re]) => re.test(line));
      if (!matched) return;
      let values = extractMoney(line);
      if (!values.length && i + 1 < lines.length) values = extractMoney(lines[i + 1]);
      if (!values.length) return;
      let score = matched[1] + i / Math.max(1, lines.length) * 2;
      if (/할인|전\s*금액|예상|변경\s*전/i.test(line)) score -= 12;
      const candidate = values[values.length - 1].value;
      if (score >= strongest.weight) strongest = { value: candidate, weight: score };
    });
    if (strongest.value > 0) return strongest.value;
    // Last resort only: choose the last reasonably large amount, not the largest product price.
    const moneyLines = lines.slice(-Math.max(8, Math.ceil(lines.length * 0.55)));
    const vals = moneyLines.filter(x => !/(사업자|전화|TEL|승인번호|카드번호|거래일|승인일|결제일|구매일|일시|날짜)/i.test(x)
      && !/\b(?:19|20)\d{2}[-./]\d{1,2}[-./]\d{1,2}\b/.test(x))
      .flatMap(extractMoney).map(x => x.value).filter(x => x >= 100);
    return vals.length ? vals[vals.length - 1] : 0;
  }
  function itemsOf(lines) {
    const items = [];
    // Trailing amount, optional quantity. Handles typical "품목명   1   1,700".
    const re = /^(.{2,60}?)\s+(?:(\d{1,3})\s+)?(\d{1,3}(?:,\d{3})+|\d{3,9})\s*원?\s*$/;
    for (const line of lines) {
      if (IGNORE_ITEM.test(line)) continue;
      const m = line.match(re);
      if (!m) continue;
      const name = m[1].replace(/^[*·•\-\s\d]{1,4}/, '').trim();
      const qty = Number(m[2] || 1);
      const price = amount(m[3]);
      if (!/[가-힣A-Za-z]/.test(name) || name.length < 2 || qty < 1 || qty > 99 || price < 100 || price > 100000000) continue;
      if (/\d{2}[:.]\d{2}/.test(name)) continue;
      items.push({ name, qty, price });
      if (items.length >= 50) break;
    }
    return items;
  }
  function parseReceipt(text) {
    const raw = normalize(text);
    const lines = raw.split('\n').map(s => s.replace(/\s+/g, ' ').trim()).filter(Boolean);
    const dateLine = lines.find(x => /(거래일|결제일|영업일|일시|날짜|승인일|구매일)/i.test(x) && parseDateString(x));
    const date = (dateLine ? parseDateString(dateLine) : '') || (lines.map(parseDateString).find(Boolean) || '');
    const merchant = merchantOf(lines);
    const total = totalOf(lines);
    const items = itemsOf(lines);
    const score = (merchant ? 20 : 0) + (date ? 20 : 0) + (total ? 35 : 0)
      + Math.min(20, items.length * 5) + Math.min(5, lines.length / 4);
    return { merchant, date, total, items, category: inferCategory(merchant, items), score: Math.round(score), raw, lines: lines.length };
  }
  function bestOfOcr(ocr) {
    const variants = ['ko', 'enhanced', 'latin']
      .filter(key => typeof ocr[key] === 'string' && ocr[key].trim())
      .map(key => ({ ...parseReceipt(ocr[key]), source: key }));
    if (!variants.length) return { merchant: '', date: '', total: 0, items: [], category: '기타', score: 0, raw: '', source: '', needsReview: true };
    variants.sort((a, b) => b.score - a.score);
    const best = { ...variants[0] };
    for (const other of variants.slice(1)) {
      if (!best.merchant && other.merchant) best.merchant = other.merchant;
      if (!best.date && other.date) best.date = other.date;
      if (!best.total && other.total) best.total = other.total;
      if (!best.items.length && other.items.length) best.items = other.items;
    }
    best.category = inferCategory(best.merchant, best.items);
    best.raw = `=== 한국어 원본 ===\n${ocr.ko || ''}\n\n=== 한국어 보정 ===\n${ocr.enhanced || ''}\n\n=== 영문 보완 ===\n${ocr.latin || ''}`;
    best.needsReview = !best.date || !best.merchant || !best.total || best.score < 75;
    return best;
  }
  const api = { parseReceipt, bestOfOcr, parseDateString, inferCategory, amount };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ReceiptParser = api;
})(typeof window !== 'undefined' ? window : globalThis);

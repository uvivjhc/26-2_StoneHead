(function () {
  'use strict';
  const $ = selector => document.querySelector(selector);
  const safe = value => String(value ?? '').replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
  const money = value => Number(value || 0).toLocaleString('ko-KR') + '원';
  const moneyNumber = value => Number(value || 0).toLocaleString('ko-KR');
  const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
  const monthNow = () => today().slice(0,7);
  const categories = ['식비','생활비','교통비','쇼핑','의료비','문화·여가','기타'];
  const meta = {
    '식비': ['🍴','#fc8f7f','#ffe5dd'],'생활비':['🏠','#609df3','#e4f0ff'],'교통비':['🚌','#3dbf96','#e3fbef'],
    '쇼핑':['🛍️','#bb83ef','#f3eaff'],'의료비':['💊','#f58a9e','#fff0f1'],'문화·여가':['🎮','#f0b54e','#fff5df'], '기타':['•••','#a6a2bf','#eeeef6']
  };
  const glyphs = {
    camera:'<path d="M14 4h-4l-2 3H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2-3Z"/><circle cx="12" cy="14" r="3"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
    edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    chart:'<path d="M3 3v18h18"/><path d="M8 16v-5M13 16V6M18 16V9"/>',
    home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z"/>',
    ledger:'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',
    more:'<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>',
    bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z"/><path d="M10 21h4"/>',
    user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    chevron:'<path d="m9 18 6-6-6-6"/>',
    back:'<path d="m15 18-6-6 6-6"/>',
    receipt:'<path d="M5 3h14v19l-3-2-4 2-4-2-3 2Z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    checkcircle:'<circle cx="12" cy="12" r="10"/><path d="m7 12 3 3 7-7"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    close:'<path d="M18 6 6 18M6 6l12 12"/>',
    scan:'<path d="M4 9V5a1 1 0 0 1 1-1h4M15 4h4a1 1 0 0 1 1 1v4M20 15v4a1 1 0 0 1-1 1h-4M9 20H5a1 1 0 0 1-1-1v-4"/><path d="M7 12h10"/>',
    alert:'<path d="M10.3 3.9 2.6 17.2A2 2 0 0 0 4.3 20h15.4a2 2 0 0 0 1.7-2.8L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4m0 4h.01"/>',
    settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 1 .3 1.8l-1.7 1.7a1.7 1.7 0 0 1-1.8.3l-1.5-.7a7 7 0 0 1-2.1.9l-.4 1.6a1.7 1.7 0 0 1-1.6 1.1H9.3a1.7 1.7 0 0 1-1.6-1.1l-.4-1.6a7 7 0 0 1-2.1-.9l-1.5.7a1.7 1.7 0 0 1-1.8-.3L.3 16.8A1.7 1.7 0 0 1 .6 15l.7-1.5a7 7 0 0 1-.9-2.1l-1.6-.4V9.3l1.6-.4a7 7 0 0 1 .9-2.1L.6 5.3 2 3.9l1.7.3 1.5.7a7 7 0 0 1 2.1-.9l.4-1.6h3l.4 1.6a7 7 0 0 1 2.1.9l1.5-.7a1.7 1.7 0 0 1 1.8.3L18 6l-.3 1.8-.7 1.5c.4.7.7 1.4.9 2.1l1.6.4v3l-1.6.4a7 7 0 0 1-.9 2.1Z"/>',
    trash:'<path d="M3 6h18M8 6V4h8v2M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
    shield:'<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/>'
  };
  const ico = (name, size) => `<svg width="${size||20}" height="${size||20}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.85" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${glyphs[name] || glyphs.receipt}</svg>`;
  const state = {
    page:'home', month:monthNow(), records:[], budget:400000, gallery:false,
    image:'', imageSize:{width:0,height:0}, crop:{left:.05,top:.03,right:.95,bottom:.97},
    processing:false, progress:0, ocrText:'', draft:null, confirmDelete:0, reviewWarning:false,
    detailed:localStorage.getItem('receiptmate.detailed') !== 'false',
    ledgerCategory:'전체', ledgerSearch:''
  };
  const hasNative = Boolean(window.Android && typeof window.Android.getRecords === 'function');
  const DemoBridge = {
    getRecords: () => localStorage.getItem('receiptmate.records') || '[]',
    saveRecord: payload => { const r = JSON.parse(payload), all = JSON.parse(DemoBridge.getRecords()); r.id = r.id || Date.now(); const found=all.findIndex(x=>x.id===r.id); if(found>=0) all[found]=r; else all.unshift(r);localStorage.setItem('receiptmate.records',JSON.stringify(all));return JSON.stringify({ok:true,id:r.id}); },
    deleteRecord: id => {const all=JSON.parse(DemoBridge.getRecords());localStorage.setItem('receiptmate.records',JSON.stringify(all.filter(x=>x.id!==id)));return true;},
    getBudget: () => Number(localStorage.getItem('receiptmate.budget') || 400000),
    setBudget: budget => localStorage.setItem('receiptmate.budget',String(budget)),
    openCamera: () => toast('실제 카메라 촬영은 Android 앱 설치 후 사용할 수 있어요.'),
    pickGallery: () => $('#browserPick')?.click(),
    startOcr: () => toast('OCR은 Android 앱 빌드에서 이용할 수 있어요.'),
    clearWorkingImage: () => {}, setScanTheme: () => {}, toast: msg => toast(msg)
  };
  const api = hasNative ? window.Android : DemoBridge;
  let toastTimer = null;
  function toast(message) {
    const box = $('#toast'); if (!box) return;
    box.textContent = String(message); box.classList.add('show');
    clearTimeout(toastTimer); toastTimer=setTimeout(()=>box.classList.remove('show'),2900);
  }
  function refreshData() {
    try { state.records = JSON.parse(api.getRecords()); if(!Array.isArray(state.records)) state.records=[]; }
    catch (e) { state.records=[]; toast('내역을 불러오지 못했습니다.'); }
    state.budget = api.getBudget();
  }
  function changeMonth(amount) {
    const [year,month] = state.month.split('-').map(Number);
    const date = new Date(year, month-1+amount, 1);
    state.month = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}`;
    render();
  }
  function monthLabel() {const [y,m] = state.month.split('-');return `${y}년 ${Number(m)}월`;}
  function recordsOfMonth(month=state.month) {return state.records.filter(r=>String(r.date||'').slice(0,7)===month);}
  function totalOf(list){return list.reduce((n,r)=>n + Number(r.total||0),0);}
  function summaries(list) {
    return categories.map(c=>({name:c,total:totalOf(list.filter(r=>r.category===c)),count:list.filter(r=>r.category===c).length}))
      .filter(v=>v.total>0).sort((a,b)=>b.total-a.total);
  }
  function monthNav(){return `<div class="monthline"><button aria-label="이전 달" class="month-arrow" data-action="prev-month">${ico('back')}</button><span class="month-title">${monthLabel()} ▾</span><button aria-label="다음 달" class="month-arrow" data-action="next-month">${ico('chevron')}</button></div>`;}
  function nav() {
    const pages=[['home','home','홈'],['ledger','ledger','가계부'],['scan','camera',''],['stats','chart','통계'],['more','more','더보기']];
    return `<nav class="nav" aria-label="하단 탐색">${pages.map(([page,icon,label])=> page==='scan'
      ? `<button class="nav-camera" data-action="go" data-page="scan" aria-label="영수증 촬영">${ico(icon)}</button>`
      : `<button class="nav-btn ${state.page===page?'active':''}" data-action="go" data-page="${page}" aria-label="${label}">${ico(icon)}<span>${label}</span></button>`).join('')}</nav>`;
  }
  function pageTitle(title,back='home',actionHtml=''){
    return `<div class="titlebar"><button class="back" data-action="go" data-page="${back}" aria-label="뒤로">${ico('back')}</button><h1>${title}</h1><div class="spacer"></div>${actionHtml}</div>`;
  }
  function transRow(r){
    const m = meta[r.category] || meta['기타'];
    return `<button class="tx-item" data-action="view" data-id="${Number(r.id)}"><span class="tx-logo">${m[0]}</span><span class="tx-main"><span class="tx-name"><span class="truncate">${safe(r.merchant)}</span><span class="chip" style="color:${m[1]};background:${m[2]}">${safe(r.category)}</span></span><span class="tx-date">${safe(r.date)}</span></span><strong class="tx-money">${money(r.total)}</strong></button>`;
  }
  function donutHtml(list,total,large=false) {
    const groups = summaries(list);
    const segment = groups.length ? groups.reduce((out,g)=>{let last=out.end, next=last+(g.total/total*100);out.parts.push(`${meta[g.name][1]} ${last}% ${next}%`);out.end=next;return out;},{end:0,parts:[]}).parts.join(',') : '#eae7fb 0% 100%';
    return `<div class="donut" style="${large?'width:172px;height:172px;':''}background:conic-gradient(${segment})"><div class="donut-center" style="${large?'width:123px;height:123px;':''}"><small>총 지출</small><strong>${money(total)}</strong></div></div>`;
  }
  function legendHtml(list,total,limit=7){
    const groups = summaries(list).slice(0,limit);
    return groups.length?groups.map(g=>{
      const m=meta[g.name];const pct = Math.round((g.total/total)*100);
      return `<div class="legend-row"><span class="legend-name"><span class="legend-icon" style="background:${m[2]}">${m[0]}</span>${safe(g.name)}</span><span class="legend-amount">${money(g.total)} <small>${pct}%</small></span></div>`;
    }).join(''):'<div style="color:#aaa6c0;font-size:12px;text-align:center">저장된 소비 내역이 없습니다.</div>';
  }
  function home(){
    const current = recordsOfMonth(), total=totalOf(current), prevMonth = (()=>{const [y,m]=state.month.split('-').map(Number),d=new Date(y,m-2,1);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;})();
    const prev = totalOf(recordsOfMonth(prevMonth));
    const percent = prev>0 ? Math.round((total-prev)/prev*100) : null;
    const badge = percent===null ? '<span class="delta">이번 달 기록</span>' : `<span class="delta" style="${percent>0?'background:#fff0ef;color:#d35b5e':''}">${percent<=0?'▼':'▲'} 지난달 대비 ${Math.abs(percent)}%</span>`;
    const progress = state.budget>0 ? Math.min(100,Math.round(total/state.budget*100)) : 0;
    return `<main class="page home-page"><header class="topbar"><div><div class="hello">안녕하세요! 👋</div><div class="subtext">오늘도 알뜰한 소비를 기록해보세요.</div></div><div class="top-icons"><button class="iconbtn" data-action="tip" aria-label="알림">${ico('bell')}</button><button class="iconbtn" data-action="go" data-page="more" aria-label="설정">${ico('user')}</button></div></header>
      <button class="hero" data-action="go" data-page="scan"><div><div class="hero-title"><span>영수증 촬영으로</span><span>지출을 자동 등록해요 ›</span></div><div class="hero-link">한국어 OCR로 빠르게 기록하기 ${ico('chevron',14)}</div></div>${ico('scan',74)}</button>
      ${monthNav()}
      <section class="card"><div class="total-label">이번 달 지출</div><div class="total-row"><strong class="amount-large">${moneyNumber(total)}<span class="won">원</span></strong>${badge}</div><div class="progress"><div class="fill" style="width:${progress}%"></div></div><div class="progress-labels"><span>예산 ${money(state.budget)}</span><span>${state.budget?Math.round(total/state.budget*100):0}%</span></div></section>
      <div class="quick-grid"><button class="quick" data-action="camera"><span class="quick-ico">${ico('camera')}</span><span>영수증 촬영</span></button><button class="quick" data-action="gallery"><span class="quick-ico">${ico('image')}</span><span>갤러리 등록</span></button><button class="quick" data-action="manual"><span class="quick-ico">${ico('edit')}</span><span>수동 입력</span></button><button class="quick" data-action="go" data-page="stats"><span class="quick-ico">${ico('chart')}</span><span>통계 보기</span></button></div>
      <section class="card"><div class="section-heading"><h2>카테고리별 지출</h2><button class="morelink" data-action="go" data-page="stats">더보기 ${ico('chevron')}</button></div><div class="stat-body">${donutHtml(current,total)}<div class="legend">${legendHtml(current,total,4)}</div></div></section>
      <section class="card"><div class="section-heading"><h2>최근 지출 내역</h2><button class="morelink" data-action="go" data-page="ledger">더보기 ${ico('chevron')}</button></div>${current.length?current.slice(0,5).map(transRow).join(''):`<div class="empty-state"><div class="empty-art">🧾</div>아직 이번 달 지출 내역이 없어요.<br>영수증을 등록하면 여기에 표시돼요.</div>`}</section>
    </main>${nav()}`;
  }
  function ledger(){
    const current = recordsOfMonth().filter(r=>(state.ledgerCategory==='전체'||r.category===state.ledgerCategory)&&(!state.ledgerSearch||r.merchant.toLowerCase().includes(state.ledgerSearch.toLowerCase())));
    const days = [...new Set(current.map(r=>r.date))].sort().reverse();
    return `<main class="page">${pageTitle('가계부')}${monthNav()}<div class="card"><div class="split-row"><span class="total-label">조회된 지출</span><strong style="font-size:21px">${money(totalOf(current))}</strong></div><div class="summary-mini">${current.length}건의 지출 내역</div><div class="field"><input aria-label="상호명 검색" type="search" data-field="ledgerSearch" placeholder="상호명으로 검색" value="${safe(state.ledgerSearch)}" /></div></div><div class="pill-tabs">${['전체',...categories].map(c=>`<button class="tabpill ${state.ledgerCategory===c?'active':''}" data-action="filter-category" data-category="${safe(c)}">${safe(c)}</button>`).join('')}</div>
      ${days.length?days.map(day=>`<div class="daylabel">${safe(day)}</div><div class="card" style="padding-top:5px;padding-bottom:12px">${current.filter(r=>r.date===day).map(transRow).join('')}</div>`).join(''):`<div class="card empty-state"><div class="empty-art">📒</div>이 기간에 표시할 지출 내역이 없습니다.</div>`}
      </main>${nav()}`;
  }
  function stats(){
    const current=recordsOfMonth(), total=totalOf(current), groups=summaries(current);
    const [y,m] = state.month.split('-').map(Number);
    const monthBars = Array.from({length:6},(_,i)=>{const d=new Date(y,m-1-5+i,1),month=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;return {month,total:totalOf(recordsOfMonth(month))};});
    const high=Math.max(1,...monthBars.map(x=>x.total));
    return `<main class="page">${pageTitle('소비 통계')}${monthNav()}<div class="card"><div class="section-heading"><h2>이번 달 소비 분포</h2><span class="muted" style="font-size:12px">${current.length}건</span></div><div style="display:grid;place-items:center;margin:14px 0 22px">${donutHtml(current,total,true)}</div><div class="legend">${legendHtml(current,total)}</div></div>
    <div class="card"><div class="section-heading"><h2>최근 6개월 지출</h2></div><div class="bars">${monthBars.map(x=>`<div class="barcol"><div class="bar" title="${safe(x.month)} ${money(x.total)}" style="height:${Math.max(2,Math.round(x.total/high*108))}px"></div><div class="bar-label">${Number(x.month.slice(5))}월</div></div>`).join('')}</div></div><div class="tipbox"><strong>💡 소비 기록 안내</strong>카테고리 통계는 실제 저장한 금액을 합산합니다. 은행·카드사의 사용 내역과 자동으로 연동되지는 않습니다.</div></main>${nav()}`;
  }
  function scan(){
    const isImage = Boolean(state.image);
    let content='';
    if (state.processing) {
      content=`<div class="scan-window" style="display:block;padding:35px 25px"><div class="ocr-progress"><div class="spinner"></div><strong style="font-size:17px">영수증을 분석하고 있어요</strong><div style="font-size:12px;margin-top:17px;color:#c7c1d3">${safe(state.ocrText)}</div><div class="dark-progress"><div class="fill" style="width:${state.progress}%"></div></div><div class="ocr-percentage">${state.progress}%</div></div></div>`;
    } else if (isImage) {
      const c=state.crop;
      content=`<div class="scan-sub">모서리의 점을 움직여 영수증 영역만 선택하세요.<br>배경을 제외하면 인식 오류를 줄이는 데 도움이 됩니다.</div><div class="photo-container"><div class="photo-wrapper" id="photoWrapper"><img src="${state.image}" alt="인식할 영수증 사진" /><div id="cropbox" class="cropbox" style="left:${c.left*100}%;top:${c.top*100}%;width:${(c.right-c.left)*100}%;height:${(c.bottom-c.top)*100}%"><span class="handle tl" data-corner="tl"></span><span class="handle tr" data-corner="tr"></span><span class="handle bl" data-corner="bl"></span><span class="handle br" data-corner="br"></span></div></div></div><button class="wide-btn" data-action="start-ocr">${ico('scan')} 한국어 OCR 분석 시작</button><div style="height:10px"></div><div class="scan-actions"><button class="ghost-btn" data-action="camera">다시 촬영</button><button class="ghost-btn" data-action="gallery">다른 사진</button></div>`;
    } else {
      content=`<div class="scan-sub">영수증 전체가 또렷하게 보이도록 촬영해 주세요.</div><div class="scan-window"><div class="scanner-outline"><div class="scanner-paper">${Array.from({length:11},(_,i)=>`<div class="dash" style="width:${i%3===0?90:60+(i%4)*10}%"></div>`).join('')}</div></div></div><div class="scan-message">빛 반사를 피하고, 글자가 흐리지 않도록 촬영하면<br>한글·금액 인식이 더 정확해져요.</div><div class="scan-actions"><button class="wide-btn" data-action="camera">${ico('camera')} 카메라 열기</button><button class="ghost-btn" data-action="gallery">${ico('image',18)} 갤러리</button></div>`;
    }
    return `<main class="scan-page">${pageTitle('영수증 촬영','home')}${content}<p class="scan-foot">${state.detailed?'✓ 정밀 인식 사용 중 · 한국어 + 영문 + 명암 보정':'기본 인식 · 한국어 + 영문'}<br>이미지는 별도 서버로 전송하지 않습니다.</p></main>`;
  }
  function field(name,label,value,type='text',placeholder='') {
    return `<div class="field"><label for="f-${name}">${label}</label><input id="f-${name}" data-draft-field="${name}" type="${type}" ${type==='number'?'min="0" inputmode="numeric"':''} value="${safe(value)}" placeholder="${safe(placeholder)}" /></div>`;
  }
  function edit(){
    const d=state.draft || newDraft();
    const items=Array.isArray(d.items)?d.items:[];
    const sum=items.reduce((n,x)=>n + Number(x.price||0),0);
    const warn=items.length && Number(d.total||0)>0 && sum!==Number(d.total||0);
    return `<main class="page">${pageTitle(d.id?'내역 수정':'영수증 등록','home',d.id?`<button class="iconbtn" data-action="ask-delete" data-id="${Number(d.id)}" aria-label="삭제">${ico('trash')}</button>`:'')}
      <div class="${state.reviewWarning?'warning-banner':'success-banner'}">${ico(state.reviewWarning?'alert':'checkcircle')}<span>${state.reviewWarning?'인식 결과를 확인해 주세요':'구매 정보를 자동으로 추출했어요!'}<small>${state.reviewWarning?'일부 정보가 누락되거나 정확하지 않을 수 있습니다.':'내용을 확인하고 필요한 부분은 수정할 수 있어요.'}</small></span></div>
      <div class="card" style="margin-top:15px">${field('merchant','상호명',d.merchant,'text','매장 이름')}${field('date','결제일',d.date,'date')}
      <div class="field"><label for="f-category">카테고리 <span class="muted" style="font-size:11px">(자동 분류 후 수정 가능)</span></label><select id="f-category" data-draft-field="category">${categories.map(c=>`<option value="${safe(c)}" ${d.category===c?'selected':''}>${safe(c)}</option>`).join('')}</select></div></div>
      <div class="split-row"><h3 class="form-title">구매 상품 (${items.length})</h3><button class="secondary-btn" data-action="add-item">${ico('plus',15)} 항목 추가</button></div>
      <div class="item-headings"><span>상품명</span><span>수량</span><span style="text-align:right">금액(원)</span><span></span></div>
      ${items.length?items.map((it,i)=>`<div class="item-card"><div class="item-line"><input aria-label="상품명 ${i+1}" data-item-index="${i}" data-item-field="name" value="${safe(it.name)}" placeholder="상품명"/><input aria-label="수량 ${i+1}" class="qty" type="number" min="1" max="99" data-item-index="${i}" data-item-field="qty" value="${Number(it.qty||1)}"/><input aria-label="금액 ${i+1}" class="price" type="number" min="0" data-item-index="${i}" data-item-field="price" value="${Number(it.price||0)}"/><button class="item-del" data-action="remove-item" data-index="${i}" aria-label="상품 삭제">${ico('close',17)}</button></div></div>`).join(''):`<div class="empty-state" style="padding:12px">인식된 상품이 없습니다. 필요하다면 항목을 추가해 주세요.</div>`}
      <div id="sumWarning">${warn?`<div class="warning-banner">상품별 금액 합계(${money(sum)})와 결제 총액이 다릅니다. 영수증을 보고 확인해 주세요.</div>`:''}</div>
      <div class="totalbox"><span>총 결제 금액</span><label style="display:flex;align-items:center;gap:3px"><input type="number" min="0" max="100000000000" inputmode="numeric" data-draft-field="total" value="${Number(d.total||0)}" aria-label="총 결제 금액" /> 원</label></div>
      ${d.raw ? `<details class="details"><summary>원본 OCR 텍스트 확인</summary><pre class="rawtext">${safe(d.raw)}</pre></details>`:''}
      <div class="sticky-actions"><button class="ghost-btn" data-action="${d.id?'go':'scan-again'}" ${d.id?'data-page="ledger"':''}>${d.id?'돌아가기':'다시 촬영'}</button><button class="wide-btn" data-action="save">${ico('check')} ${d.id?'수정 내용 저장':'가계부에 등록'}</button></div>
    </main>${state.confirmDelete?deleteModal():''}`;
  }
  function more(){
    return `<main class="page">${pageTitle('설정 및 도구')}<div class="card"><h2 style="font-size:16px;margin:0 0 14px">월 예산 설정</h2><div class="field"><label for="budget">한 달 예산 (원)</label><input id="budget" type="number" min="0" max="1000000000" value="${Number(state.budget)}" /></div><button class="wide-btn" data-action="save-budget">예산 저장하기</button></div>
      <div class="card"><h2 style="font-size:16px;margin:0 0 14px">영수증 인식</h2><div class="settingline"><span><b>정밀 OCR 사용</b><br><small class="muted">한글 원본·명암 보정·영문 보완 교차 검사</small></span><button class="toggle ${state.detailed?'on':''}" data-action="toggle-detailed" aria-label="정밀 OCR ${state.detailed?'끄기':'켜기'}" role="switch" aria-checked="${state.detailed}"></button></div><div class="settingline"><span><b>수동 입력</b><br><small class="muted">인식이 어려울 때 직접 기록</small></span><button class="secondary-btn" data-action="manual">열기</button></div></div>
      <div class="card"><h2 style="font-size:16px;margin:0 0 14px">테스트 데이터</h2><p class="note">화면 확인이 필요하면 '예시'라고 표시된 내역 3건을 추가할 수 있습니다. 실제 거래 데이터와 구별됩니다.</p><button class="ghost-btn" style="width:100%;" data-action="add-demo">시연용 예시 3건 추가</button></div>
      <div class="tipbox"><strong>${ico('shield',17)} 개인정보·저장 안내</strong>영수증 인식은 기기 내부에서 처리되며, 가계부는 이 앱의 SQLite 데이터베이스에 저장됩니다. 카드·은행 계좌 연동과 외부 서버 업로드는 구현하지 않았습니다. 앱을 삭제하면 로컬 기록도 삭제될 수 있습니다.</div><div class="note" style="text-align:center;margin:22px">영수증 가계부 · 캡스톤 프로토타입 v1.0</div>
    </main>${nav()}`;
  }
  function deleteModal(){return `<div class="modal-bg"><div class="modal"><h3>지출 내역을 삭제할까요?</h3><p>삭제된 거래는 복원할 수 없습니다.</p><div class="modal-actions"><button class="ghost-btn" data-action="cancel-delete">취소</button><button class="wide-btn" style="background:#db6265" data-action="delete">삭제</button></div></div></div>`;}
  function render(){
    const old=$('#scrollmain');
    const markup=({home,ledger,stats,scan,editor:edit,more})[state.page]?.() || home();
    $('#app').innerHTML=markup;
    api.setScanTheme(state.page==='scan');
  }
  function navigate(page){
    if(state.processing && page !== 'scan'){toast('분석이 완료된 뒤 이동할 수 있어요.');return;}
    if(!['home','ledger','stats','scan','editor','more'].includes(page)) page='home';
    state.page=page; state.confirmDelete=0;
    if(page==='home'||page==='ledger'||page==='stats') refreshData();
    render(); window.scrollTo(0,0);
  }
  function newDraft(){return {merchant:'',date:today(),category:'기타',total:0,items:[],raw:''};}
  function manual(){state.draft=newDraft();state.reviewWarning=false;navigate('editor');}
  function chooseCamera(){navigate('scan');api.openCamera();}
  function chooseGallery(){navigate('scan');api.pickGallery();}
  function editRecord(id){const found=state.records.find(x=>Number(x.id)===Number(id));if(!found)return toast('내역을 찾을 수 없습니다.');state.draft=JSON.parse(JSON.stringify(found));state.reviewWarning=false;navigate('editor');}
  function save(){
    const d=state.draft;if(!d)return;
    d.merchant=String(d.merchant||'').trim(); d.total=Number(d.total);
    if(!d.merchant){toast('상호명을 입력해 주세요.');$('#f-merchant')?.focus();return;}
    if(!ReceiptParser.parseDateString(d.date)||ReceiptParser.parseDateString(d.date)!==d.date){toast('결제일을 정확하게 선택해 주세요.');$('#f-date')?.focus();return;}
    if(!Number.isSafeInteger(d.total)||d.total<=0||d.total>100000000000){toast('결제 금액을 올바르게 입력해 주세요.');return;}
    if(d.items.some(item=>!item.name||Number(item.qty)<1||Number(item.price)<0)){toast('상품 정보를 확인해 주세요.');return;}
    try {
      const result=JSON.parse(api.saveRecord(JSON.stringify(d)));
      if(!result.ok){toast(result.error||'저장할 수 없습니다.');return;}
      refreshData(); state.image='';state.draft=null;api.clearWorkingImage();navigate('home');toast('가계부에 저장했어요.');
    } catch(e){toast('저장 중 오류가 발생했어요.');}
  }
  function updateSums(){
    const d=state.draft;
    if(!d)return;
    const sum=d.items.reduce((n,x)=>n+Number(x.price||0),0);
    const mismatch=d.items.length&&d.total>0&&sum!==Number(d.total||0);
    const el=$('#sumWarning'); if(el)el.innerHTML=mismatch?`<div class="warning-banner">상품별 금액 합계(${money(sum)})와 결제 총액이 다릅니다. 영수증을 보고 확인해 주세요.</div>`:'';
  }
  function addDemo(){
    const when=today(); const samples=[
      {merchant:'CU 편의점 (예시)',date:when,category:'식비',total:12900,items:[{name:'도시락',qty:1,price:5900},{name:'음료',qty:2,price:7000}]},
      {merchant:'이마트 (예시)',date:when,category:'생활비',total:45800,items:[{name:'생활용품',qty:1,price:45800}]},
      {merchant:'스타벅스 (예시)',date:when,category:'식비',total:6500,items:[{name:'아메리카노',qty:1,price:6500}]}
    ];
    let added=0;for(const s of samples){const result=JSON.parse(api.saveRecord(JSON.stringify({...s,raw:'시연용으로 생성한 가상 거래입니다.'})));if(result.ok)added++;}
    refreshData();navigate('home');toast(`예시 데이터 ${added}건을 추가했어요.`);
  }
  function handleAction(el){
    const action=el.dataset.action;
    switch(action){
      case 'go':navigate(el.dataset.page);break;
      case 'prev-month':changeMonth(-1);break;
      case 'next-month':changeMonth(1);break;
      case 'camera':chooseCamera();break;
      case 'gallery':chooseGallery();break;
      case 'manual':manual();break;
      case 'tip':toast('영수증을 촬영하거나 갤러리에서 선택해 보세요.');break;
      case 'start-ocr':state.processing=true;state.progress=5;state.ocrText='이미지를 준비하고 있어요…';render();api.startOcr(JSON.stringify(state.crop),state.detailed);break;
      case 'scan-again':state.image='';api.clearWorkingImage();navigate('scan');break;
      case 'view':editRecord(Number(el.dataset.id));break;
      case 'save':save();break;
      case 'add-item':state.draft?.items.push({name:'',qty:1,price:0});render();break;
      case 'remove-item':state.draft?.items.splice(Number(el.dataset.index),1);render();break;
      case 'filter-category':state.ledgerCategory=el.dataset.category;render();break;
      case 'save-budget':{const n=Number($('#budget')?.value);if(!Number.isInteger(n)||n<0||n>1000000000)return toast('예산을 0~10억 원 사이로 입력해 주세요.');api.setBudget(n);state.budget=n;toast('예산을 저장했어요.');break;}
      case 'toggle-detailed':state.detailed=!state.detailed;localStorage.setItem('receiptmate.detailed',String(state.detailed));render();break;
      case 'add-demo':addDemo();break;
      case 'ask-delete':state.confirmDelete=Number(el.dataset.id);render();break;
      case 'cancel-delete':state.confirmDelete=0;render();break;
      case 'delete':{
        const id=state.confirmDelete; if(api.deleteRecord(id)){state.confirmDelete=0;state.draft=null;refreshData();navigate('ledger');toast('내역이 삭제되었습니다.');}else toast('삭제하지 못했습니다.');break;
      }
    }
  }
  document.addEventListener('click',event=>{const item=event.target.closest('[data-action]');if(item){event.preventDefault();handleAction(item);}});
  document.addEventListener('input',event=>{
    const el=event.target;
    if(el.dataset.draftField && state.draft){state.draft[el.dataset.draftField]=el.dataset.draftField==='total'?Number(el.value):el.value; if(el.dataset.draftField==='total')updateSums();}
    if(el.dataset.itemField && state.draft){const item=state.draft.items[Number(el.dataset.itemIndex)];if(item){item[el.dataset.itemField] = el.dataset.itemField==='name' ? el.value : Number(el.value);updateSums();}}
    if(el.dataset.field==='ledgerSearch'){state.ledgerSearch=el.value; /* update on change to keep focus */ }
  });
  document.addEventListener('change',event=>{
    if(event.target.dataset.field==='ledgerSearch') render();
    if(event.target.dataset.draftField && state.draft) state.draft[event.target.dataset.draftField] = event.target.value;
  });
  let dragging=null;
  document.addEventListener('pointerdown',event=>{
    const handle=event.target.closest('[data-corner]');
    if(!handle)return;
    dragging=handle.dataset.corner;
    try{handle.setPointerCapture(event.pointerId);}catch(e){}
    event.preventDefault();
  });
  document.addEventListener('pointermove',event=>{
    if(!dragging)return;
    const wrapper=$('#photoWrapper');if(!wrapper)return;
    const r=wrapper.getBoundingClientRect();
    const x=Math.max(.01,Math.min(.99,(event.clientX-r.left)/r.width));
    const y=Math.max(.01,Math.min(.99,(event.clientY-r.top)/r.height));
    const c=state.crop, min=.13;
    if(dragging.endsWith('l'))c.left=Math.min(x,c.right-min);else c.right=Math.max(x,c.left+min);
    if(dragging.startsWith('t'))c.top=Math.min(y,c.bottom-min);else c.bottom=Math.max(y,c.top+min);
    const box=$('#cropbox');if(box) Object.assign(box.style,{left:c.left*100+'%',top:c.top*100+'%',width:(c.right-c.left)*100+'%',height:(c.bottom-c.top)*100+'%'});
  });
  document.addEventListener('pointerup',()=>dragging=null);
  document.addEventListener('pointercancel',()=>dragging=null);
  // Browser-only visual preview accepts imported images; OCR requires native ML Kit.
  const picker=document.createElement('input');picker.id='browserPick';picker.type='file';picker.accept='image/*';picker.hidden=true;document.body.appendChild(picker);
  picker.addEventListener('change',()=>{const file=picker.files?.[0];if(!file)return;const reader=new FileReader();reader.onload=()=>App.onImageReady(reader.result,0,0);reader.readAsDataURL(file);});
  const App = window.App = {
    onNativeError(message){state.processing=false;state.progress=0;render();toast(message);},
    onPickerCancelled(){if(state.page==='scan')toast('이미지 선택이 취소되었습니다.');},
    onImageLoading(){state.processing=true;state.progress=5;state.ocrText='사진을 불러오고 있어요…';render();},
    onImageReady(dataUrl,width,height){state.image=dataUrl;state.imageSize={width,height};state.crop={left:.05,top:.03,right:.95,bottom:.97};state.processing=false;state.progress=0;navigate('scan');},
    onOcrProgress(message,percent){state.ocrText=String(message);state.progress=Math.max(0,Math.min(100,Number(percent)||0));if(state.page==='scan')render();},
    onOcrComplete(result){
      state.processing=false;state.progress=100;
      const p=ReceiptParser.bestOfOcr(result||{});
      state.reviewWarning=p.needsReview;
      state.draft={merchant:p.merchant||'',date:p.date||today(),category:p.category||'기타',total:p.total||0,items:p.items||[],raw:p.raw||''};
      if(!p.raw.trim() && result.error)toast('OCR 분석에 실패하여 수동 입력으로 전환합니다.');
      navigate('editor');
    },
    onAndroidBack(){
      if(state.confirmDelete){state.confirmDelete=0;render();return;}
      if(state.page==='editor' && state.draft && !state.draft.id){state.image='';api.clearWorkingImage();navigate('home');return;}
      if(state.page!=='home'){navigate('home');return;}
      toast('홈 화면입니다.');
    }
  };
  refreshData();render();
})();

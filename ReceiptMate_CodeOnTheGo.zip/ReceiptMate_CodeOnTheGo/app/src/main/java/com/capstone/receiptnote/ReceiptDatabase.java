package com.capstone.receiptnote;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

final class ReceiptDatabase extends SQLiteOpenHelper {
    private static final int SCHEMA_VERSION = 1;

    ReceiptDatabase(Context context) {
        super(context, "receiptmate_private.db", null, SCHEMA_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE expenses (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "merchant TEXT NOT NULL," +
                "spent_date TEXT NOT NULL," +
                "category TEXT NOT NULL," +
                "total INTEGER NOT NULL," +
                "items_json TEXT NOT NULL," +
                "raw_text TEXT NOT NULL," +
                "created_at TEXT NOT NULL DEFAULT (datetime('now')))");
        db.execSQL("CREATE INDEX index_expenses_date ON expenses(spent_date)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Future migration must preserve expenses; do not delete data here.
    }

    synchronized String getAllJson() {
        JSONArray result = new JSONArray();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT id,merchant,spent_date,category,total,items_json,raw_text,created_at " +
                "FROM expenses ORDER BY spent_date DESC, id DESC", null)) {
            while (c.moveToNext()) {
                JSONObject row = new JSONObject();
                row.put("id", c.getLong(0));
                row.put("merchant", c.getString(1));
                row.put("date", c.getString(2));
                row.put("category", c.getString(3));
                row.put("total", c.getLong(4));
                row.put("items", new JSONArray(c.getString(5)));
                row.put("raw", c.getString(6));
                row.put("createdAt", c.getString(7));
                result.put(row);
            }
        } catch (Exception e) {
            return "[]";
        }
        return result.toString();
    }

    synchronized String saveJson(String json) {
        JSONObject response = new JSONObject();
        try {
            JSONObject input = new JSONObject(json);
            String merchant = input.optString("merchant", "").trim();
            String date = input.optString("date", "").trim();
            String category = input.optString("category", "기타").trim();
            long total = input.getLong("total");
            if (merchant.isEmpty() || merchant.length() > 120) throw new IllegalArgumentException("상호명은 1~120자로 입력하세요.");
            if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) throw new IllegalArgumentException("날짜는 YYYY-MM-DD 형식이어야 합니다.");
            if (total <= 0 || total > 100000000000L) throw new IllegalArgumentException("금액을 올바르게 입력하세요.");
            if (category.isEmpty() || category.length() > 30) category = "기타";
            JSONArray items = input.optJSONArray("items");
            if (items == null) items = new JSONArray();
            String raw = input.optString("raw", "");
            if (raw.length() > 60000) raw = raw.substring(0, 60000);

            ContentValues values = new ContentValues();
            values.put("merchant", merchant);
            values.put("spent_date", date);
            values.put("category", category);
            values.put("total", total);
            values.put("items_json", items.toString());
            values.put("raw_text", raw);
            SQLiteDatabase db = getWritableDatabase();
            long id = input.optLong("id", 0);
            if (id > 0) {
                int count = db.update("expenses", values, "id=?", new String[]{String.valueOf(id)});
                if (count == 0) throw new IllegalArgumentException("수정할 내역을 찾지 못했습니다.");
            } else {
                id = db.insertOrThrow("expenses", null, values);
            }
            response.put("ok", true);
            response.put("id", id);
        } catch (Exception e) {
            try { response.put("ok", false); response.put("error", e.getMessage()); } catch (Exception ignored) { }
        }
        return response.toString();
    }

    synchronized boolean deleteRecord(long id) {
        return id > 0 && getWritableDatabase().delete("expenses", "id=?", new String[]{String.valueOf(id)}) == 1;
    }
}

package com.capstone.receiptnote;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.exifinterface.media.ExifInterface;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Native Android shell for the offline WebView dashboard.
 * The webpage is packaged under android_asset and cannot navigate to remote content.
 * All OCR is on-device with bundled ML Kit Korean and Latin models.
 */
public class MainActivity extends Activity {
    private static final int REQUEST_CAMERA = 2101;
    private static final int REQUEST_GALLERY = 2102;
    private WebView webView;
    private ReceiptDatabase database;
    private TextRecognizer koreanRecognizer;
    private TextRecognizer latinRecognizer;
    private final ExecutorService imageExecutor = Executors.newSingleThreadExecutor();
    private File cameraFile;
    private Bitmap workingBitmap;
    private boolean ocrBusy = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        database = new ReceiptDatabase(this);
        koreanRecognizer = TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
        latinRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(248, 247, 255));
        getWindow().setNavigationBarColor(android.graphics.Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(248, 247, 255));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        webView.addJavascriptInterface(new NativeBridge(), "Android");
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void executeJs(String js) {
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private void notifyError(String message) {
        executeJs("window.App && App.onNativeError(" + JSONObject.quote(message) + ");");
    }

    private void launchCamera() {
        if (ocrBusy) return;
        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (dir == null) throw new IllegalStateException("사진을 저장할 공간이 없습니다.");
            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("카메라 폴더를 만들 수 없습니다.");
            cameraFile = new File(dir, "scan_" + System.currentTimeMillis() + ".jpg");
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", cameraFile);
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
            intent.setClipData(android.content.ClipData.newRawUri("receipt", uri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_CAMERA);
        } catch (Exception e) { notifyError("카메라를 열 수 없습니다: " + e.getMessage()); }
    }

    private void launchGallery() {
        if (ocrBusy) return;
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_GALLERY);
        } catch (Exception e) { notifyError("사진을 선택할 수 없습니다: " + e.getMessage()); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CAMERA && requestCode != REQUEST_GALLERY) return;
        if (resultCode != RESULT_OK) {
            executeJs("App.onPickerCancelled();");
            return;
        }
        Uri uri;
        if (requestCode == REQUEST_CAMERA) {
            if (cameraFile == null || !cameraFile.exists() || cameraFile.length() == 0) {
                notifyError("촬영한 사진을 찾지 못했습니다. 다시 촬영해 주세요.");
                return;
            }
            uri = Uri.fromFile(cameraFile);
        } else {
            uri = data != null ? data.getData() : null;
        }
        if (uri == null) {
            notifyError("선택한 이미지에 접근할 수 없습니다.");
            return;
        }
        executeJs("App.onImageLoading();");
        imageExecutor.execute(() -> {
            try {
                Bitmap loaded = readBitmap(uri);
                if (loaded == null) throw new IllegalStateException("이미지 디코딩에 실패했습니다.");
                Bitmap preview = fitBitmap(loaded, 900);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                preview.compress(Bitmap.CompressFormat.JPEG, 76, bytes);
                String dataUrl = "data:image/jpeg;base64," + android.util.Base64.encodeToString(bytes.toByteArray(), android.util.Base64.NO_WRAP);
                runOnUiThread(() -> {
                    if (workingBitmap != null && workingBitmap != loaded && !workingBitmap.isRecycled()) workingBitmap.recycle();
                    workingBitmap = loaded;
                    executeJs("App.onImageReady(" + JSONObject.quote(dataUrl) + "," + loaded.getWidth() + "," + loaded.getHeight() + ");");
                });
                if (preview != loaded) preview.recycle();
            } catch (Exception e) {
                notifyError("사진을 열지 못했습니다: " + e.getMessage());
            } catch (OutOfMemoryError err) {
                notifyError("이미지가 너무 큽니다. 더 작은 사진을 선택해 주세요.");
            }
        });
    }

    private Bitmap readBitmap(Uri uri) throws Exception {
        BitmapFactory.Options size = new BitmapFactory.Options();
        size.inJustDecodeBounds = true;
        try (InputStream stream = getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(stream, null, size);
        }
        if (size.outWidth <= 0 || size.outHeight <= 0) throw new IllegalArgumentException("지원하지 않는 이미지입니다.");
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inSampleSize = 1;
        int maxDimension = Math.max(size.outWidth, size.outHeight);
        while (maxDimension / options.inSampleSize > 3600) options.inSampleSize *= 2;
        Bitmap bitmap;
        try (InputStream stream = getContentResolver().openInputStream(uri)) {
            bitmap = BitmapFactory.decodeStream(stream, null, options);
        }
        if (bitmap == null) throw new IllegalArgumentException("JPG 또는 PNG 파일을 선택해 주세요.");
        int rotation = 0;
        try (InputStream stream = getContentResolver().openInputStream(uri)) {
            if (stream != null) {
                int orientation = new ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                switch (orientation) {
                    case ExifInterface.ORIENTATION_ROTATE_90: rotation = 90; break;
                    case ExifInterface.ORIENTATION_ROTATE_180: rotation = 180; break;
                    case ExifInterface.ORIENTATION_ROTATE_270: rotation = 270; break;
                    default: break;
                }
            }
        } catch (Exception ignored) { }
        if (rotation != 0) {
            Matrix matrix = new Matrix();
            matrix.postRotate(rotation);
            Bitmap rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            if (rotated != bitmap) bitmap.recycle();
            bitmap = rotated;
        }
        return bitmap;
    }

    private static Bitmap fitBitmap(Bitmap image, int maxSide) {
        int largest = Math.max(image.getWidth(), image.getHeight());
        if (largest <= maxSide) return image;
        float factor = (float) maxSide / largest;
        return Bitmap.createScaledBitmap(image, Math.max(1, Math.round(image.getWidth() * factor)),
                Math.max(1, Math.round(image.getHeight() * factor)), true);
    }

    private static Bitmap cropBitmap(Bitmap source, String json) throws Exception {
        JSONObject box = new JSONObject(json);
        double left = Math.max(0, Math.min(0.95, box.optDouble("left", 0)));
        double top = Math.max(0, Math.min(0.95, box.optDouble("top", 0)));
        double right = Math.max(left + 0.04, Math.min(1, box.optDouble("right", 1)));
        double bottom = Math.max(top + 0.04, Math.min(1, box.optDouble("bottom", 1)));
        int x = Math.min(source.getWidth() - 1, (int) Math.floor(left * source.getWidth()));
        int y = Math.min(source.getHeight() - 1, (int) Math.floor(top * source.getHeight()));
        int width = Math.max(1, Math.min(source.getWidth() - x, (int) Math.ceil((right - left) * source.getWidth())));
        int height = Math.max(1, Math.min(source.getHeight() - y, (int) Math.ceil((bottom - top) * source.getHeight())));
        Bitmap cropped = Bitmap.createBitmap(source, x, y, width, height);
        return fitBitmap(cropped, 3000);
    }

    private static Bitmap contrastForReceipt(Bitmap source) {
        Bitmap target = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(target);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        // Grayscale + slightly stronger contrast to recover faint thermal-printer text.
        ColorMatrix gray = new ColorMatrix();
        gray.setSaturation(0f);
        ColorMatrix contrast = new ColorMatrix(new float[] {
                1.35f, 0, 0, 0, -37,
                0, 1.35f, 0, 0, -37,
                0, 0, 1.35f, 0, -37,
                0, 0, 0, 1, 0
        });
        gray.postConcat(contrast);
        paint.setColorFilter(new ColorMatrixColorFilter(gray));
        canvas.drawBitmap(source, 0, 0, paint);
        return target;
    }

    private void startOcr(String crop, boolean detailed) {
        if (ocrBusy) return;
        if (workingBitmap == null || workingBitmap.isRecycled()) {
            notifyError("먼저 영수증을 촬영하거나 선택해 주세요.");
            return;
        }
        ocrBusy = true;
        executeJs("App.onOcrProgress('한국어 문자를 인식하고 있어요…',20);");
        Bitmap bitmap;
        try { bitmap = cropBitmap(workingBitmap, crop); }
        catch (Exception e) {
            ocrBusy = false;
            notifyError("이미지 영역 지정에 문제가 있습니다: " + e.getMessage());
            return;
        }
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        koreanRecognizer.process(image)
                .addOnSuccessListener(result -> processEnhanced(bitmap, detailed, result.getText(), null))
                .addOnFailureListener(e -> processEnhanced(bitmap, detailed, "", "한국어 인식: " + e.getMessage()));
    }

    private void processEnhanced(Bitmap bitmap, boolean detailed, String primary, String firstError) {
        if (!detailed) {
            processLatin(bitmap, primary, "", firstError);
            return;
        }
        executeJs("App.onOcrProgress('흐린 글씨를 보정하고 있어요…',52);");
        imageExecutor.execute(() -> {
            try {
                Bitmap improved = contrastForReceipt(bitmap);
                runOnUiThread(() -> koreanRecognizer.process(InputImage.fromBitmap(improved, 0))
                        .addOnSuccessListener(result -> {
                            improved.recycle();
                            processLatin(bitmap, primary, result.getText(), firstError);
                        })
                        .addOnFailureListener(e -> {
                            improved.recycle();
                            processLatin(bitmap, primary, "", firstError);
                        }));
            } catch (Exception | OutOfMemoryError e) {
                runOnUiThread(() -> processLatin(bitmap, primary, "", firstError));
            }
        });
    }

    private void processLatin(Bitmap bitmap, String ko, String enhanced, String error) {
        executeJs("App.onOcrProgress('매장명과 금액을 교차 확인해요…',80);");
        latinRecognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener(result -> finishOcr(bitmap, ko, enhanced, result.getText(), error))
                .addOnFailureListener(e -> finishOcr(bitmap, ko, enhanced, "", error == null ? e.getMessage() : error));
    }

    private void finishOcr(Bitmap bitmap, String ko, String enhanced, String latin, String error) {
        ocrBusy = false;
        try {
            JSONObject result = new JSONObject();
            result.put("ko", ko);
            result.put("enhanced", enhanced);
            result.put("latin", latin);
            result.put("error", error == null ? "" : error);
            executeJs("App.onOcrComplete(" + result.toString() + ");");
        } catch (Exception e) { notifyError("OCR 결과 전달에 실패했습니다."); }
        if (bitmap != workingBitmap && !bitmap.isRecycled()) bitmap.recycle();
    }

    public final class NativeBridge {
        @JavascriptInterface public String getRecords() { return database.getAllJson(); }
        @JavascriptInterface public String saveRecord(String payload) { return database.saveJson(payload); }
        @JavascriptInterface public boolean deleteRecord(long id) { return database.deleteRecord(id); }
        @JavascriptInterface public int getBudget() {
            return getSharedPreferences("settings", MODE_PRIVATE).getInt("budget", 400000);
        }
        @JavascriptInterface public void setBudget(int budget) {
            getSharedPreferences("settings", MODE_PRIVATE).edit()
                    .putInt("budget", Math.max(0, Math.min(budget, 1000000000))).apply();
        }
        @JavascriptInterface public void openCamera() { runOnUiThread(MainActivity.this::launchCamera); }
        @JavascriptInterface public void pickGallery() { runOnUiThread(MainActivity.this::launchGallery); }
        @JavascriptInterface public void startOcr(String crop, boolean detailed) {
            runOnUiThread(() -> MainActivity.this.startOcr(crop, detailed));
        }
        @JavascriptInterface public void clearWorkingImage() {
            runOnUiThread(() -> {
                if (ocrBusy) return;
                if (workingBitmap != null && !workingBitmap.isRecycled()) workingBitmap.recycle();
                workingBitmap = null;
                if (cameraFile != null && cameraFile.exists()) cameraFile.delete();
                cameraFile = null;
            });
        }
        @JavascriptInterface public void setScanTheme(boolean scan) {
            runOnUiThread(() -> {
                getWindow().setStatusBarColor(scan ? android.graphics.Color.rgb(30, 28, 40) : android.graphics.Color.rgb(248, 247, 255));
                getWindow().setNavigationBarColor(scan ? android.graphics.Color.rgb(30, 28, 40) : android.graphics.Color.WHITE);
                getWindow().getDecorView().setSystemUiVisibility(scan ? 0 :
                        View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            });
        }
        @JavascriptInterface public void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    @Override public void onBackPressed() {
        executeJs("App.onAndroidBack();");
    }

    @Override protected void onDestroy() {
        imageExecutor.shutdownNow();
        if (koreanRecognizer != null) koreanRecognizer.close();
        if (latinRecognizer != null) latinRecognizer.close();
        if (workingBitmap != null && !workingBitmap.isRecycled()) workingBitmap.recycle();
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
            webView = null;
        }
        database.close();
        super.onDestroy();
    }
}

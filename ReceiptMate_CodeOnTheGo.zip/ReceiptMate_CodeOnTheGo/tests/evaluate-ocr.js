/**
 * Example: node tests/evaluate-ocr.js tests/example-evaluation.json
 * Input format: [{"ocr":{"ko":"...","enhanced":"...","latin":"..."},
 *                  "truth":{"merchant":"...","date":"YYYY-MM-DD","total":1000,"category":"식비"}}]
 * Reports field-level extraction accuracy (not CER/WER).
 */
const fs=require('node:fs');
const P=require('../app/src/main/assets/receipt-parser.js');
const file=process.argv[2];
if(!file){console.error('Usage: node tests/evaluate-ocr.js tests/example-evaluation.json');process.exit(2);}
const samples=JSON.parse(fs.readFileSync(file,'utf8'));
if(!Array.isArray(samples)||!samples.length)throw Error('Nonempty array required');
const names=['merchant','date','total','category'];
const correct=Object.fromEntries(names.map(n=>[n,0]));
for(const sample of samples){
 const actual=P.bestOfOcr(sample.ocr||{}),truth=sample.truth||{};
 for(const field of names){
  const a=field==='merchant'?String(actual[field]||'').replace(/\s+/g,'').toLowerCase():actual[field];
  const b=field==='merchant'?String(truth[field]||'').replace(/\s+/g,'').toLowerCase():truth[field];
  if(a===b)correct[field]++;
 }
}
console.log(`Receipt sample count: ${samples.length}`);
for(const n of names)console.log(`${n}: ${(correct[n]/samples.length*100).toFixed(1)}% (${correct[n]}/${samples.length})`);
console.log('NOTE: This evaluates parsed field accuracy only; OCR character error rate requires ground-truth transcription.');

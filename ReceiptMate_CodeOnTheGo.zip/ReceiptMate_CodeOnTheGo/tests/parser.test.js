const assert = require('node:assert/strict');
const P = require('../app/src/main/assets/receipt-parser.js');
const receipt = `CU 서울대입구점
서울 관악구 관악로 1
거래일시 2026-11-05 14:26
상품명   수량   금액
삼각김밥(참치마요) 1 1,700
바나나우유 1 1,800
포카칩 1 1,600
합계 5,100원
카드결제 5,100원`;
const actual = P.parseReceipt(receipt);
assert.equal(actual.merchant, 'CU 서울대입구점');
assert.equal(actual.date, '2026-11-05');
assert.equal(actual.total, 5100);
assert.equal(actual.category, '식비');
assert.equal(actual.items.length, 3);
assert.equal(P.parseDateString('25/02/29'), '');
assert.equal(P.parseDateString('2024.02.29'), '2024-02-29');
assert.equal(P.parseDateString('20261105'), '2026-11-05');
const mixed = P.bestOfOcr({ko:'상호명: 이마트\n2026.11.05\n합계 12,300원',enhanced:'',latin:''});
assert.equal(mixed.total, 12300);
assert.equal(mixed.date, '2026-11-05');
assert.equal(mixed.merchant, '이마트');
const failure = P.bestOfOcr({ko:'',enhanced:'',latin:''});
assert.equal(failure.needsReview, true);
assert.equal(P.parseReceipt('CU 편의점\n거래일시 2026-11-05 12:00').total, 0);
assert.equal(P.parseReceipt('CU 편의점\n사업자번호 123-45-67890\n2026.11.05').total, 0);
console.log('PASS: Receipt parser 11 assertions / scenarios');

const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const parser=fs.readFileSync(__dirname+'/../app/src/main/assets/receipt-parser.js','utf8');
const app=fs.readFileSync(__dirname+'/../app/src/main/assets/app.js','utf8');
const root={innerHTML:''},toast={textContent:'',classList:{add(){},remove(){}}};
const memory={};
const elements={'#app':root,'#toast':toast};
const listeners={};
const context={
  console,Date,Number,Array,String,Object,JSON,Math,Set,Map,
  setTimeout,clearTimeout,
  localStorage:{getItem:k=>memory[k]??null,setItem:(k,v)=>memory[k]=v},
  document:{querySelector:s=>elements[s]||null,createElement:()=>({hidden:true,addEventListener(){},files:[]}),body:{appendChild(){}},addEventListener:(n,fn)=>listeners[n]=fn},
  scrollTo(){},
};
context.window=context;
context.window.localStorage=context.localStorage;
context.window.document=context.document;
context.window.setTimeout=setTimeout;
context.window.clearTimeout=clearTimeout;
vm.createContext(context);
vm.runInContext(parser,context);
vm.runInContext(app,context);
assert.match(root.innerHTML,/카테고리별 지출/);
assert.match(root.innerHTML,/영수증 촬영/);
const receipt=`CU 서울대입구점\n거래일시 2026-11-05 14:26\n삼각김밥 1 1,700\n합계 1,700원`;
context.window.App.onOcrComplete({ko:receipt,enhanced:receipt,latin:'CU Seoul'});
assert.match(root.innerHTML,/구매 상품/);
assert.match(root.innerHTML,/가계부에 등록/);
assert.match(root.innerHTML,/1700/);
// Simulate saving the OCR result to the browser demo repository.
const clickAction=(action,more={})=>listeners.click({target:{closest:()=>({dataset:{action,...more}})},preventDefault(){}});
clickAction('save');
assert.match(root.innerHTML,/1,700원/);
clickAction('go',{page:'ledger'});
assert.match(root.innerHTML,/CU 서울대입구점/);
clickAction('go',{page:'stats'});
assert.match(root.innerHTML,/소비 통계/);
clickAction('go',{page:'home'});
assert.match(root.innerHTML,/안녕하세요/);
console.log('PASS: home render / OCR edit / save / ledger / stats / navigation');

# 영수증 가계부 (ReceiptMate) — Code on the Go Android project

**프로젝트 상태:** 앱 소스 프로젝트 및 정적·JavaScript 테스트 완료. 이 환경에는 Android SDK/Gradle이 없어서 실제 APK 빌드와 휴대전화 OCR/카메라 실행 검증은 아직 수행하지 못했습니다.

이 프로젝트는 소프트웨어 캡스톤 디자인 문서의 FR-001~FR-009를 기반으로 작성한 **실제 Android 앱 프로젝트**입니다. 완성 APK가 아니라 Code on the Go에서 열어 **Gradle Sync → Build/Run** 해야 하는 소스 ZIP입니다.

## 실행하기 (Code on the Go 26.38 이상 / R2 기준)

1. 이 ZIP을 Android의 **내 파일 / Files** 앱에서 압축 해제합니다. `ReceiptMate_CodeOnTheGo` 폴더가 생기도록 압축을 해제하세요.
2. **Code on the Go**를 실행합니다. 초기 도구 설치(설정)는 완료되어 있어야 합니다.
3. **Open existing project(기존 프로젝트 열기)**를 선택합니다. 압축을 해제한 **`ReceiptMate_CodeOnTheGo` 폴더 자체**를 선택하세요. `app` 폴더나 ZIP 파일을 선택하는 것이 아닙니다.
4. Gradle Sync를 수행합니다. 처음에는 ML Kit, AndroidX 같은 외부 의존성을 Google Maven/Maven Central에서 내려받아야 하므로 **인터넷이 필요할 수 있습니다**. 오프라인 캐시가 비어 있다면 CoGo의 Build & Run → Additional Gradle flags에서 `--offline`을 해제하세요.
5. **Run / Build APK**로 빌드·설치합니다. 설치 후 카메라 촬영 또는 갤러리에서 실제 영수증 이미지를 등록합니다.

> CoGo R2 기본 툴체인에 맞춘 `Gradle 9.6.1 / AGP 9.3.1 / Java 17` 구성입니다. `compileSdk 36`, `minSdk 23`, `targetSdk 34`로 구성했습니다. `targetSdk 34`는 프로토타입의 UI/호환성을 고려한 값이며 Play 스토어 게시 요구사항을 위한 최종 설정이 아닙니다.
>
> `gradle/wrapper/gradle-wrapper.properties`는 제공하지만, 정품 `gradle-wrapper.jar`는 네트워크 제한으로 내려받아 검증할 수 없어 포함하지 않았습니다. CoGo의 프로젝트 빌드 기능을 사용하세요. 터미널의 `./gradlew`는 CoGo에 설치된 `gradle` 실행 파일을 활용하는 간단한 진입점입니다.

## 구현한 기능

| ID | 기능 | 구현 방식 |
|---|---|---|
| FR-001 | 영수증 촬영·사진 선택 | 외부 기본 카메라 앱 촬영 + Android 문서 선택기 + FileProvider |
| FR-002 | 한국어 OCR | Google ML Kit 한국어 전용 모델 번들 + 영문 모델 보완 |
| FR-003 | 정보 구조화 | 상호명·결제일·합계·상품명·수량·금액 파싱(규칙·키워드) |
| FR-004 | 수정 | 상호명·날짜·카테고리·상품·수량·총액 모두 수정 가능 |
| FR-005 | 자동 분류 | 식비/생활비/교통비/쇼핑/의료비/문화·여가/기타 키워드 기반 |
| FR-006 | 가계부 저장 | 앱 전용 SQLite (`receiptmate_private.db`) CRUD |
| FR-007 | 날짜·월별 조회 | 월 이동, 상호명 검색, 카테고리 필터, 내역 수정/삭제 |
| FR-008 | 소비 통계 | 카테고리별 금액·지출 비율 |
| FR-009 | 시각화 | 원형 도넛 차트, 최근 6개월 막대그래프 |

UI는 제공된 참고 이미지의 **연보라/흰색 대시보드, 4개 빠른 동작, 보라색 촬영 강조, 영수증 촬영 단계, 결과 편집, 하단 5개 메뉴**를 구현한 모바일 반응형 디자인입니다. 전용 앱 내부 미리보기 카메라가 아니라 **기기의 기본 카메라 앱을 호출**하는 방식입니다. OCR 영역 선택 및 분석 단계는 앱 안에서 진행합니다.

## 한국어 OCR 정확도 개선 방식

1. **ML Kit Text Recognition v2 한국어 모델** `com.google.mlkit:text-recognition-korean:16.0.1`을 APK에 포함합니다. 네트워크 OCR API 및 비밀 API 키는 사용하지 않습니다.
2. **이미지 방향 보정:** AndroidX ExifInterface로 촬영/갤러리 JPEG의 EXIF 90°/180°/270° 회전을 수정합니다.
3. **고해상도 유지:** 긴 변 최대 약 3,000px을 인식 입력으로 사용합니다. 지나치게 큰 파일은 샘플링 디코딩하여 메모리 부족을 예방합니다.
4. **영수증 범위 지정:** 사용자가 네 모서리를 드래그해 배경을 제거할 수 있습니다. 문자가 충분히 크고 초점이 맞아야 합니다.
5. **정밀 인식 기본 켜짐:** 한국어 원본 + 회색조/명암 개선 이미지 한국어 재인식 + 영문 인식 결과를 각각 분석합니다. 결과 구조화 점수로 후보를 비교하고 누락 필드만 보완합니다. 정밀 인식은 3회 처리되므로 처리시간이 길어질 수 있습니다.
6. **한국형 영수증 규칙:** `YYYY.MM.DD`, `YY-MM-DD`, `YYYYMMDD` 등의 날짜, `합계`, `결제금액`, `총액`, `카드결제` 등의 총액 라벨을 우선합니다. 상호명, 품목, 수량, 금액을 규칙 기반으로 추출합니다.
7. **불확실한 결과 검토:** 추출 누락 시 경고 배너, 수정 입력란, 원본 OCR 텍스트, 품목 합계와 결제 총액 불일치 표시를 제공합니다. 사용자가 확인하기 전에는 가계부에 자동 저장하지 않습니다.

**중요:** 특정 영수증의 인식률, 5초 이내 처리나 90% 정확도 달성을 보장하지 않습니다. 표준 영수증뿐 아니라 영수증 폭·조명·인쇄 상태·한글/영문 혼용·할인 등 별도 테스트 데이터에서 측정해야 합니다. 영수증 인쇄품의 모든 형식에 대응하는 범용 파서가 아닙니다.

## 화면과 테스트 방법

- **홈:** 월별 지출·예산 진행률·카테고리 원형그래프·최근 거래(처음에는 0원).
- **영수증 촬영:** 실제 카메라 호출 또는 갤러리 선택 → 화면에서 영수증 영역 모서리 지정 → OCR 분석.
- **등록:** 인식 정보 확인 및 수정(상품 개별 입력 포함) → 가계부에 등록. 인식 실패 시 수동 입력으로 복구.
- **가계부:** 월 이동, 카테고리/상호명 필터, 상세정보 편집, 삭제.
- **통계:** 해당 월 지출 비율 및 6개월 합계.
- **더보기:** 월 예산, 정밀 인식 켜기/끄기, 테스트 데이터 3건 추가, 개인정보 설명.

첫 실행에서 화면이 비어 보이는 것은 정상입니다. 실제 지출이 없으므로 가상의 사용 내역을 임의로 삽입하지 않습니다. UI 테스트 데이터가 필요하면 **더보기 → 시연용 예시 3건 추가**를 사용하세요. 예시가 명시된 가상 거래만 삽입합니다.

### 개발자 테스트

- `node tests/parser.test.js` — 날짜/합계/상호명/품목/미인식 처리 검증
- `node tests/ui-smoke.test.js` — 홈 화면 구성 및 OCR 결과 편집 전환 검증
- 실제 Android 디바이스에서 `카메라 → 촬영 → 영역 지정 → OCR → 수정 → 저장 → 통계` 흐름의 기능 테스트가 추가로 필요합니다.

## 의존성 / 기술적 선택

- Android Java + 단일 `Activity`의 로컬 WebView UI (JavaScript/HTML/CSS). **단일 프로젝트를 CoGo에서 앱으로 빌드**하며 단순 웹 사이트 배포물이 아닙니다.
- ML Kit Korean Text Recognition `16.0.1`, Latin Text Recognition `16.0.1` (온디바이스 번들 모델)
- AndroidX Core `1.16.0` (FileProvider)
- AndroidX ExifInterface `1.4.1`
- Android SQLiteOpenHelper (외부 DB 계정 불필요)
- 별도 `INTERNET` 권한, 사진 저장소 전역 권한, 카메라 권한 요청 없음. 카메라 앱/시스템 문서 선택기에 위임합니다.

**현재 제외:** 금융기관 자동연동, OCR/이미지 모델 직접 학습, 서버 로그인·동기화, 카드 내역 조회, 영수증 자동 촬영 감지, 실제 앱 내부 라이브 카메라 미리보기, 데이터 백업·복원. 초기 문서의 Must/Should 범위에서 벗어나는 항목이며 추후 확장할 수 있습니다.

## 코드 구조

```
ReceiptMate_CodeOnTheGo/
  settings.gradle, build.gradle, gradle.properties, gradlew
  app/
    build.gradle
    src/main/AndroidManifest.xml
    src/main/java/com/capstone/receiptnote/
      MainActivity.java     # 카메라, OCR, 네이티브 ↔ UI 브리지
      ReceiptDatabase.java # 로컬 SQLite CRUD
    src/main/assets/
      index.html
      styles.css
      app.js               # 모든 UI, 탐색, 차트, 수동 수정
      receipt-parser.js    # 한국어 영수증 필드 파서
    src/main/res/...
  tests/
    parser.test.js
    ui-smoke.test.js
  docs/
    original-design-reference.png
```

## 출처

- [Code on the Go 공식 소개](https://appdevforall.org/code-on-the-go/)
- [CoGo 최신 AGP/Gradle 빌드 환경 안내](https://github.com/appdevforall/CodeOnTheGo/wiki/IMPORTANT:-Fix-project-breaking-changes-after-the-Gradle-AGP-Kotlin-toolchain-upgrade)
- [Google ML Kit Android Text Recognition v2](https://developers.google.com/ml-kit/vision/text-recognition/v2/android?hl=ko)
- [Google ML Kit 모델별 출시 내역](https://developers.google.cn/ml-kit/release-notes?hl=ko)
- [Naver Cloud CLOVA OCR 공식 가이드](https://guide.ncloud-docs.com/docs/clovaocr-overview) — 유료/온라인 서버 연동으로 확장할 때 비교할 수 있지만 이번 버전에는 포함하지 않음.

### KPI 측정 보조 스크립트

`node tests/evaluate-ocr.js tests/example-evaluation.json`을 실행하면 샘플 단위로 매장명·날짜·총액·카테고리 추출 일치율을 계산합니다. `example-evaluation.json`은 **형식 확인용 가상 영수증 1건**이므로, 이 결과를 실제 정확도나 목표 KPI 달성의 증거로 사용하면 안 됩니다. 직접 수집한 테스트용 영수증에서 OCR 결과와 정답을 대조한 JSON으로 대체해야 합니다.
